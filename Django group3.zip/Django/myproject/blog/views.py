from django.shortcuts import render, get_object_or_404
from .models import Post
from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect


def home(request):
    return render(request, 'home.html')


def books(request):
    return render(request, 'books.html')


def categories(request):
    return render(request, 'categories.html')


def about(request):
    return render(request, 'about.html')


def contact(request):
    return render(request, 'contact.html')


def post_detail(request, post_id):
    post = get_object_or_404(Post, id=post_id)

    return render(request, 'post_detail.html', {
        'post': post
    })

def login_view(request):

    if request.method == 'POST':

        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(
            request,
            username=username,
            password=password
        )

        if user is not None:
            login(request, user)
            return redirect('home')

    return render(request, 'login.html')