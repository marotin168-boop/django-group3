from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),

    path('books/', views.books, name='books'),

    path('categories/', views.categories, name='categories'),

    path('about/', views.about, name='about'),

    path('contact/', views.contact, name='contact'),

    path('login/', views.login_view, name='login'),

    path('post/<int:post_id>/', views.post_detail, name='post_detail'),
]